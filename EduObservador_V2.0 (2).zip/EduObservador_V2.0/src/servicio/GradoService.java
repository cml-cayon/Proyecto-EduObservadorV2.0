package servicio;

import java.util.List;
import modelo.grado.Grado;
import repositorio.DataRepository;

public class GradoService {
    private DataRepository<Grado> repo = new DataRepository<>("data/grados.dat");
    private List<Grado> grados;

    public GradoService() {
        grados = repo.load();
    }

    public List<Grado> getGrados() { return grados; }

    public void addGrado(Grado g) {
        grados.add(g);
        save();
    }

    public void removeGrado(Grado g) {
        grados.remove(g);
        save();
    }

    public Grado findByNombre(String nombre) {
        for (Grado g : grados) {
            if (g.getNombre().equalsIgnoreCase(nombre)) return g;
        }
        return null;
    }

    public void save() {
        repo.save(grados);
    }
}
