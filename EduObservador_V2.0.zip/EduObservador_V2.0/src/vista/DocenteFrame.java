package vista;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import modelo.observacion.Observacion;
import modelo.usuario.Docente;
import servicio.AuthService;
import servicio.ObservacionService;

public class DocenteFrame extends JFrame {

    private Docente docente;
    private ObservacionService service;
    private AuthService auth;
    private DefaultTableModel tableModel;
    private JTable obsTable;

    public DocenteFrame(Docente docente, ObservacionService service, AuthService auth) {
        this.docente = docente;
        this.service = service;
        this.auth = auth;

        setTitle("EduObservador \u2013 Docente");
        setSize(900, 640);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setMinimumSize(new Dimension(750, 520));

        buildUI();
    }

    private void buildUI() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(UITheme.COLOR_BG);

        JPanel nav = UITheme.navBar("Docente: " + docente.getNombre(), "Materia: " + docente.getMateria());
        JPanel navRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 14));
        navRight.setOpaque(false);

        JButton btnPerfil = UITheme.iconButton("\u2699");
        btnPerfil.setToolTipText("Perfil y configuraci\u00f3n");
        JButton btnLogout = UITheme.iconButton("Salir");
        btnLogout.setToolTipText("Cerrar sesi\u00f3n");

        btnPerfil.addActionListener(e -> new PerfilDialog(this, docente, () -> auth.save()).setVisible(true));
        btnLogout.addActionListener(e -> logout());

        navRight.add(btnPerfil);
        navRight.add(btnLogout);
        nav.add(navRight, BorderLayout.EAST);

        JPanel content = new JPanel(new BorderLayout(12, 12));
        content.setBackground(UITheme.COLOR_BG);
        content.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        JPanel formCard = UITheme.card();
        formCard.setLayout(new BoxLayout(formCard, BoxLayout.Y_AXIS));
        formCard.setPreferredSize(new Dimension(290, 0));
        formCard.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(210, 220, 240), 1, true),
            BorderFactory.createEmptyBorder(18, 18, 18, 18)
        ));

        JLabel formTitle = UITheme.sectionLabel("Registrar Observaci\u00f3n");
        formTitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        String today = LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        JLabel fechaInfo = new JLabel("Fecha: " + today);
        fechaInfo.setFont(UITheme.FONT_BODY);
        fechaInfo.setForeground(UITheme.COLOR_TEXT_MUTED);
        fechaInfo.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel materiaInfo = new JLabel("Materia: " + docente.getMateria());
        materiaInfo.setFont(UITheme.FONT_BODY);
        materiaInfo.setForeground(UITheme.COLOR_TEXT_MUTED);
        materiaInfo.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel lblEst = new JLabel("Nombre del estudiante:");
        lblEst.setFont(UITheme.FONT_BODY);
        lblEst.setAlignmentX(Component.LEFT_ALIGNMENT);
        JTextField txtEst = UITheme.textField();
        txtEst.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        txtEst.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel lblGrado = new JLabel("Grado:");
        lblGrado.setFont(UITheme.FONT_BODY);
        lblGrado.setAlignmentX(Component.LEFT_ALIGNMENT);
        JTextField txtGrado = UITheme.textField();
        txtGrado.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        txtGrado.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel lblGrav = new JLabel("Gravedad:");
        lblGrav.setFont(UITheme.FONT_BODY);
        lblGrav.setAlignmentX(Component.LEFT_ALIGNMENT);
        JComboBox<String> cmbGrav = UITheme.comboBox(new String[]{"1 - Leve", "2 - Grave", "3 - Grav\u00edsima"});
        cmbGrav.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        cmbGrav.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel lblDesc = new JLabel("Descripci\u00f3n:");
        lblDesc.setFont(UITheme.FONT_BODY);
        lblDesc.setAlignmentX(Component.LEFT_ALIGNMENT);
        JTextArea txtDesc = new JTextArea(4, 1);
        txtDesc.setFont(UITheme.FONT_BODY);
        txtDesc.setLineWrap(true);
        txtDesc.setWrapStyleWord(true);
        txtDesc.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(190, 205, 230), 1, true),
            BorderFactory.createEmptyBorder(6, 8, 6, 8)
        ));
        JScrollPane descScroll = new JScrollPane(txtDesc);
        descScroll.setMaximumSize(new Dimension(Integer.MAX_VALUE, 90));
        descScroll.setAlignmentX(Component.LEFT_ALIGNMENT);

        JButton btnRegistrar = UITheme.primaryButton("Registrar Observaci\u00f3n");
        btnRegistrar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        btnRegistrar.setAlignmentX(Component.LEFT_ALIGNMENT);

        formCard.add(formTitle);
        formCard.add(Box.createVerticalStrut(8));
        formCard.add(fechaInfo);
        formCard.add(Box.createVerticalStrut(2));
        formCard.add(materiaInfo);
        formCard.add(Box.createVerticalStrut(16));
        formCard.add(lblEst);
        formCard.add(Box.createVerticalStrut(4));
        formCard.add(txtEst);
        formCard.add(Box.createVerticalStrut(10));
        formCard.add(lblGrado);
        formCard.add(Box.createVerticalStrut(4));
        formCard.add(txtGrado);
        formCard.add(Box.createVerticalStrut(10));
        formCard.add(lblGrav);
        formCard.add(Box.createVerticalStrut(4));
        formCard.add(cmbGrav);
        formCard.add(Box.createVerticalStrut(10));
        formCard.add(lblDesc);
        formCard.add(Box.createVerticalStrut(4));
        formCard.add(descScroll);
        formCard.add(Box.createVerticalStrut(16));
        formCard.add(btnRegistrar);

        JPanel rightPanel = new JPanel(new BorderLayout(0, 10));
        rightPanel.setOpaque(false);

        JLabel obsTitle = UITheme.sectionLabel("Observaciones Registradas");

        String[] cols = {"Fecha", "Estudiante", "Grado", "Gravedad", "Descripci\u00f3n"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        obsTable = new JTable(tableModel);
        obsTable.setFont(UITheme.FONT_BODY);
        obsTable.setRowHeight(30);
        obsTable.setShowGrid(false);
        obsTable.setIntercellSpacing(new Dimension(0, 1));
        obsTable.setBackground(Color.WHITE);
        obsTable.setSelectionBackground(new Color(220, 235, 255));
        obsTable.getTableHeader().setFont(UITheme.FONT_SUBTITLE);
        obsTable.getTableHeader().setBackground(UITheme.COLOR_PRIMARY);
        obsTable.getTableHeader().setForeground(Color.WHITE);
        obsTable.setDefaultRenderer(Object.class, new GravedadRenderer());
        UITheme.enableTooltipAndDetail(obsTable, new String[]{"Fecha", "Estudiante", "Grado", "Gravedad", "Descripci\u00f3n"});

        refreshTable();

        rightPanel.add(obsTitle, BorderLayout.NORTH);
        rightPanel.add(new JScrollPane(obsTable), BorderLayout.CENTER);

        btnRegistrar.addActionListener(e -> {
            String est = txtEst.getText().trim();
            String grado = txtGrado.getText().trim();
            String desc = txtDesc.getText().trim();

            if (est.isEmpty() || grado.isEmpty() || desc.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor completa todos los campos.", "Campos requeridos", JOptionPane.WARNING_MESSAGE);
                return;
            }

            String gravSel = (String) cmbGrav.getSelectedItem();
            String gravCode = String.valueOf(gravSel.charAt(0));
            String fecha = LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

            service.registrar(new Observacion(est, grado, gravCode, docente.getMateria(), fecha, desc));
            refreshTable();

            txtEst.setText("");
            txtGrado.setText("");
            txtDesc.setText("");
            JOptionPane.showMessageDialog(this, "Observaci\u00f3n registrada.", "\u00c9xito", JOptionPane.INFORMATION_MESSAGE);
        });

        content.add(formCard, BorderLayout.WEST);
        content.add(rightPanel, BorderLayout.CENTER);

        root.add(nav, BorderLayout.NORTH);
        root.add(content, BorderLayout.CENTER);
        setContentPane(root);
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        for (Observacion o : service.listar()) {
            tableModel.addRow(new Object[]{
                o.getFecha(), o.getEstudiante(), o.getGrado(),
                UITheme.gravedadLabel(o.getGravedad()), o.getDescripcion()
            });
        }
    }

    private void logout() {
        Object[] opciones = {"S\u00ed", "No"};
        int r = JOptionPane.showOptionDialog(this, "\u00bfCerrar sesi\u00f3n?", "Confirmar",
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);
        if (r == 0) {
            new controlador.LoginController().show();
            dispose();
        }
    }

    private class GravedadRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int col) {
            Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, col);
            if (!isSelected) {
                String grav = (String) table.getModel().getValueAt(row, 3);
                Color bg = Color.WHITE;
                if ("Leve".equals(grav)) bg = new Color(255, 252, 220);
                else if ("Grave".equals(grav)) bg = new Color(255, 237, 210);
                else if ("Grav\u00edsima".equals(grav)) bg = new Color(255, 220, 220);
                c.setBackground(bg);
            }
            ((JLabel) c).setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
            return c;
        }
    }
}
