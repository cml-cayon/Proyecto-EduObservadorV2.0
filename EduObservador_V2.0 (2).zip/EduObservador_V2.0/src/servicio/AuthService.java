package servicio;

import java.util.List;
import modelo.usuario.*;
import repositorio.DataRepository;

public class AuthService {
    private DataRepository<Usuario> repo = new DataRepository<>("data/usuarios.dat");
    private List<Usuario> usuarios;

    public AuthService() {
        usuarios = repo.load();
        if (usuarios.isEmpty()) {
            usuarios.add(new Administrador());
            save();
        }
    }

    public Usuario login(String user, String pass) {
        for (Usuario u : usuarios) {
            if (u.getUsername().equals(user) && u.getPassword().equals(pass)) {
                return u;
            }
        }
        return null;
    }

    public List<Usuario> getUsuarios() { return usuarios; }

    public void addUsuario(Usuario u) {
        usuarios.add(u);
        save();
    }

    public void deleteUsuario(Usuario u) {
        usuarios.remove(u);
        save();
    }

    public void save() {
        repo.save(usuarios);
    }
}
