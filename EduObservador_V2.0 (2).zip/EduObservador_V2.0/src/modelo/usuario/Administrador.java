package modelo.usuario;

public class Administrador extends Usuario {
    private static final long serialVersionUID = 1L;

    public Administrador() {
        super("Administrador", "-", "admin@edu.com", "admin", "admin123");
    }

    @Override
    public String getRol() { return "Administrador"; }
}
