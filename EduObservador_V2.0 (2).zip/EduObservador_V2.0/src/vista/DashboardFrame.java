package vista;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

import modelo.usuario.*;
import modelo.observacion.Observacion;
import modelo.grado.Grado;
import servicio.*;

public class DashboardFrame extends JFrame {

    private AuthService auth;
    private ObservacionService obs;
    private GradoService gradoService;
    private Usuario admin;

    private DefaultTableModel usuariosModel;
    private DefaultTableModel obsModel;
    private JTable usuariosTable;
    private JTable obsTable;

    private JComboBox<String> filtroGrado;
    private JComboBox<String> filtroOrden;

    public DashboardFrame(Usuario admin, AuthService auth, ObservacionService obs) {
        this.admin = admin;
        this.auth = auth;
        this.obs = obs;
        this.gradoService = new GradoService();

        setTitle("EduObservador \u2013 Panel de Administrador");
        setSize(950, 680);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setMinimumSize(new Dimension(800, 580));

        buildUI();
    }

    private void buildUI() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(UITheme.COLOR_BG);

        JPanel nav = UITheme.navBar("Panel de Administrador", "EduObservador \u2013 Gesti\u00f3n Escolar");
        JPanel navRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 14));
        navRight.setOpaque(false);

        JButton btnPerfil = UITheme.iconButton("Perfil");
        btnPerfil.setToolTipText("Perfil y configuraci\u00f3n");
        JButton btnLogout = UITheme.iconButton("Salir");
        btnLogout.setToolTipText("Cerrar sesi\u00f3n");

        btnPerfil.addActionListener(e -> openPerfil());
        btnLogout.addActionListener(e -> logout());

        navRight.add(btnPerfil);
        navRight.add(btnLogout);
        nav.add(navRight, BorderLayout.EAST);

        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(UITheme.FONT_SUBTITLE);
        tabs.setBackground(UITheme.COLOR_BG);
        tabs.addTab("Usuarios", buildUsuariosTab());
        tabs.addTab("Observaciones", buildObservacionesTab());
        tabs.addTab("Grados", buildGradosTab());

        root.add(nav, BorderLayout.NORTH);
        root.add(tabs, BorderLayout.CENTER);
        setContentPane(root);
    }

    private JPanel buildUsuariosTab() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(UITheme.COLOR_BG);
        panel.setBorder(BorderFactory.createEmptyBorder(14, 14, 14, 14));

        JPanel toolbar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        toolbar.setOpaque(false);
        JButton btnAddEst = UITheme.primaryButton("+ Estudiante");
        JButton btnAddDoc = UITheme.primaryButton("+ Docente");
        JButton btnDel = UITheme.dangerButton("Eliminar");
        JButton btnRefresh = UITheme.accentButton("Actualizar");

        toolbar.add(btnAddEst);
        toolbar.add(btnAddDoc);
        toolbar.add(btnDel);
        toolbar.add(btnRefresh);

        String[] cols = {"Rol", "Nombre", "Usuario", "Correo", "Grado/Materia", "Nacimiento"};
        usuariosModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        usuariosTable = styledTable(usuariosModel);
        refreshUsuariosTable();

        btnAddEst.addActionListener(e -> registrarEstudiante());
        btnAddDoc.addActionListener(e -> registrarDocente());
        btnDel.addActionListener(e -> eliminarUsuario());
        btnRefresh.addActionListener(e -> refreshUsuariosTable());

        panel.add(toolbar, BorderLayout.NORTH);
        panel.add(new JScrollPane(usuariosTable), BorderLayout.CENTER);
        return panel;
    }

    private void refreshUsuariosTable() {
        usuariosModel.setRowCount(0);
        for (Usuario u : auth.getUsuarios()) {
            String extra = "";
            if (u instanceof Docente) extra = "Materia: " + ((Docente) u).getMateria();
            else if (u instanceof Estudiante) extra = "Grado: " + ((Estudiante) u).getGrado();
            usuariosModel.addRow(new Object[]{
                u.getRol(), u.getNombre(), u.getUsername(),
                u.getCorreo(), extra, u.getFechaNacimiento()
            });
        }
    }

    private void registrarEstudiante() {
        JTextField nombre = UITheme.textField();
        JTextField fecha = UITheme.textField();
        JTextField grado = UITheme.textField();
        JTextField correo = UITheme.textField();

        JPanel form = formPanel(new String[]{"Nombre completo:", "Fecha de nacimiento:", "Grado:", "Correo electr\u00f3nico:"},
                new JComponent[]{nombre, fecha, grado, correo});

        int r = JOptionPane.showConfirmDialog(this, form, "Registrar Estudiante",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (r != JOptionPane.OK_OPTION) return;

        if (nombre.getText().isBlank() || grado.getText().isBlank()) {
            JOptionPane.showMessageDialog(this, "Nombre y Grado son obligatorios.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String user = generarUser(nombre.getText());
        Estudiante est = new Estudiante(nombre.getText().trim(), fecha.getText().trim(),
                correo.getText().trim(), grado.getText().trim(), user, "12345678");
        auth.addUsuario(est);

        Grado g = gradoService.findByNombre(grado.getText().trim());
        if (g == null) {
            g = new Grado(grado.getText().trim());
            gradoService.addGrado(g);
        }
        g.addEstudiante(nombre.getText().trim());
        gradoService.save();

        refreshUsuariosTable();
        JOptionPane.showMessageDialog(this,
                "Estudiante registrado exitosamente.\n\nUsuario: " + user + "\nContrase\u00f1a: 12345678",
                "Registro exitoso", JOptionPane.INFORMATION_MESSAGE);
    }

    private void registrarDocente() {
        JTextField nombre = UITheme.textField();
        JTextField fecha = UITheme.textField();
        JTextField materia = UITheme.textField();
        JTextField correo = UITheme.textField();

        JPanel form = formPanel(new String[]{"Nombre completo:", "Fecha de nacimiento:", "Materia:", "Correo electr\u00f3nico:"},
                new JComponent[]{nombre, fecha, materia, correo});

        int r = JOptionPane.showConfirmDialog(this, form, "Registrar Docente",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (r != JOptionPane.OK_OPTION) return;

        if (nombre.getText().isBlank() || materia.getText().isBlank()) {
            JOptionPane.showMessageDialog(this, "Nombre y Materia son obligatorios.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String user = generarUser(nombre.getText());
        auth.addUsuario(new Docente(nombre.getText().trim(), fecha.getText().trim(),
                correo.getText().trim(), materia.getText().trim(), user, "12345678"));
        refreshUsuariosTable();
        JOptionPane.showMessageDialog(this,
                "Docente registrado exitosamente.\n\nUsuario: " + user + "\nContrase\u00f1a: 12345678",
                "Registro exitoso", JOptionPane.INFORMATION_MESSAGE);
    }

    private void eliminarUsuario() {
        int row = usuariosTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Selecciona un usuario de la tabla.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String rol = (String) usuariosModel.getValueAt(row, 0);
        if ("Administrador".equals(rol)) {
            JOptionPane.showMessageDialog(this, "No se puede eliminar al administrador.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String nombre = (String) usuariosModel.getValueAt(row, 1);
        Object[] opciones = {"S\u00ed", "No"};
        int conf = JOptionPane.showOptionDialog(this, "\u00bfEliminar a " + nombre + "?", "Confirmar",
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);
        if (conf != 0) return;

        String user = (String) usuariosModel.getValueAt(row, 2);
        auth.getUsuarios().removeIf(u -> u.getUsername().equals(user));
        auth.save();
        refreshUsuariosTable();
    }

    private JPanel buildObservacionesTab() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(UITheme.COLOR_BG);
        panel.setBorder(BorderFactory.createEmptyBorder(14, 14, 14, 14));

        JPanel filterBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        filterBar.setOpaque(false);

        filtroGrado = new JComboBox<>();
        filtroGrado.setPreferredSize(new Dimension(160, 32));
        filtroGrado.setFont(UITheme.FONT_BODY);
        refreshGradoCombo();

        filtroOrden = new JComboBox<>(new String[]{"M\u00e1s reciente primero", "M\u00e1s antiguo primero", "Por gravedad (mayor)"});
        filtroOrden.setPreferredSize(new Dimension(210, 32));
        filtroOrden.setFont(UITheme.FONT_BODY);

        JButton btnFiltrar = UITheme.primaryButton("Filtrar");
        JButton btnRefreshObs = UITheme.accentButton("Actualizar");

        btnFiltrar.addActionListener(e -> refreshObsTable());
        btnRefreshObs.addActionListener(e -> { refreshGradoCombo(); refreshObsTable(); });

        filterBar.add(new JLabel("Grado:"));
        filterBar.add(filtroGrado);
        filterBar.add(new JLabel("Orden:"));
        filterBar.add(filtroOrden);
        filterBar.add(btnFiltrar);
        filterBar.add(btnRefreshObs);

        String[] cols = {"Fecha", "Estudiante", "Grado", "Gravedad", "Materia", "Descripci\u00f3n"};
        obsModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        obsTable = styledTable(obsModel);
        obsTable.setDefaultRenderer(Object.class, new ObsTableRenderer());
        UITheme.enableTooltipAndDetail(obsTable, new String[]{"Fecha", "Estudiante", "Grado", "Gravedad", "Materia", "Descripci\u00f3n"});
        refreshObsTable();

        panel.add(filterBar, BorderLayout.NORTH);
        panel.add(new JScrollPane(obsTable), BorderLayout.CENTER);
        return panel;
    }

    private void refreshGradoCombo() {
        if (filtroGrado == null) return;
        String sel = (String) filtroGrado.getSelectedItem();
        filtroGrado.removeAllItems();
        filtroGrado.addItem("Todos los grados");
        for (Grado g : gradoService.getGrados()) filtroGrado.addItem(g.getNombre());
        for (Observacion o : obs.listar()) {
            boolean found = false;
            for (int i = 0; i < filtroGrado.getItemCount(); i++) {
                if (filtroGrado.getItemAt(i).equals(o.getGrado())) { found = true; break; }
            }
            if (!found) filtroGrado.addItem(o.getGrado());
        }
        if (sel != null) filtroGrado.setSelectedItem(sel);
    }

    private void refreshObsTable() {
        obsModel.setRowCount(0);
        String gradoFiltro = filtroGrado != null ? (String) filtroGrado.getSelectedItem() : "Todos los grados";
        int orden = filtroOrden != null ? filtroOrden.getSelectedIndex() : 0;

        List<Observacion> lista = new ArrayList<>(obs.listar());
        if (gradoFiltro != null && !gradoFiltro.equals("Todos los grados")) {
            lista = lista.stream().filter(o -> o.getGrado().equalsIgnoreCase(gradoFiltro)).collect(Collectors.toList());
        }
        if (orden == 1) {
            Collections.reverse(lista);
        } else if (orden == 2) {
            lista.sort((a, b) -> b.getGravedad().compareTo(a.getGravedad()));
        }

        for (Observacion o : lista) {
            obsModel.addRow(new Object[]{o.getFecha(), o.getEstudiante(), o.getGrado(),
                    UITheme.gravedadLabel(o.getGravedad()), o.getMateria(), o.getDescripcion()});
        }
    }

    private JPanel buildGradosTab() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(UITheme.COLOR_BG);
        panel.setBorder(BorderFactory.createEmptyBorder(14, 14, 14, 14));

        JPanel left = new JPanel(new BorderLayout(0, 8));
        left.setOpaque(false);
        left.setPreferredSize(new Dimension(220, 0));

        JPanel toolbar = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
        toolbar.setOpaque(false);
        JButton btnAdd = UITheme.primaryButton("+ Grado");
        JButton btnDel = UITheme.dangerButton("Eliminar");
        toolbar.add(btnAdd);
        toolbar.add(btnDel);

        DefaultListModel<String> gradoListModel = new DefaultListModel<>();
        JList<String> gradoList = new JList<>(gradoListModel);
        gradoList.setFont(UITheme.FONT_BODY);
        gradoList.setSelectionBackground(UITheme.COLOR_PRIMARY_LIGHT);
        gradoList.setSelectionForeground(Color.WHITE);
        gradoList.setCellRenderer(new DefaultListCellRenderer() {
            @Override public Component getListCellRendererComponent(JList<?> list, Object value, int idx, boolean sel, boolean focus) {
                JLabel lbl = (JLabel) super.getListCellRendererComponent(list, value, idx, sel, focus);
                lbl.setBorder(BorderFactory.createEmptyBorder(6, 10, 6, 10));
                lbl.setText("  " + value);
                return lbl;
            }
        });

        DefaultTableModel estudModel = new DefaultTableModel(new String[]{"Estudiante", "Correo", "Usuario"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable estudTable = styledTable(estudModel);

        JLabel gradoTitleLabel = UITheme.sectionLabel("Selecciona un grado");

        Runnable refreshGrados = () -> {
            gradoListModel.clear();
            for (Grado g : gradoService.getGrados()) gradoListModel.addElement(g.getNombre());
        };
        refreshGrados.run();

        gradoList.addListSelectionListener(e -> {
            if (e.getValueIsAdjusting()) return;
            String sel = gradoList.getSelectedValue();
            if (sel == null) return;
            gradoTitleLabel.setText("Grado: " + sel);
            estudModel.setRowCount(0);
            Grado g = gradoService.findByNombre(sel);
            if (g != null) {
                for (String nombre : g.getEstudiantesNombres()) {
                    String correo = "", user = "";
                    for (Usuario u : auth.getUsuarios()) {
                        if (u instanceof Estudiante && u.getNombre().equalsIgnoreCase(nombre)) {
                            correo = u.getCorreo();
                            user = u.getUsername();
                            break;
                        }
                    }
                    estudModel.addRow(new Object[]{nombre, correo, user});
                }
            }
        });

        btnAdd.addActionListener(e -> {
            String nombre = JOptionPane.showInputDialog(this, "Nombre del grado (ej: 10\u00b0A):");
            if (nombre == null || nombre.isBlank()) return;
            if (gradoService.findByNombre(nombre) != null) {
                JOptionPane.showMessageDialog(this, "Ese grado ya existe.", "Aviso", JOptionPane.WARNING_MESSAGE);
                return;
            }
            gradoService.addGrado(new Grado(nombre.trim()));
            refreshGrados.run();
        });

        btnDel.addActionListener(e -> {
            String sel = gradoList.getSelectedValue();
            if (sel == null) return;
            Object[] opciones = {"S\u00ed", "No"};
            int conf = JOptionPane.showOptionDialog(this, "\u00bfEliminar grado " + sel + "?", "Confirmar",
                    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);
            if (conf != 0) return;
            Grado g = gradoService.findByNombre(sel);
            if (g != null) gradoService.removeGrado(g);
            estudModel.setRowCount(0);
            gradoTitleLabel.setText("Selecciona un grado");
            refreshGrados.run();
        });

        left.add(toolbar, BorderLayout.NORTH);
        left.add(new JScrollPane(gradoList), BorderLayout.CENTER);

        JPanel right = new JPanel(new BorderLayout(0, 8));
        right.setOpaque(false);
        right.add(gradoTitleLabel, BorderLayout.NORTH);
        right.add(new JScrollPane(estudTable), BorderLayout.CENTER);

        panel.add(left, BorderLayout.WEST);
        panel.add(right, BorderLayout.CENTER);
        return panel;
    }

    private void openPerfil() {
        new PerfilDialog(this, admin, () -> auth.save()).setVisible(true);
    }

    private void logout() {
        Object[] opciones = {"S\u00ed", "No"};
        int r = JOptionPane.showOptionDialog(this, "\u00bfCerrar sesi\u00f3n?", "Confirmar",
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);
        if (r == 0) {
            new controlador.LoginController().show();
            dispose();
        }
    }

    private String generarUser(String nombre) {
        String[] p = nombre.toLowerCase().trim().split("\\s+");
        if (p.length >= 2) return "" + p[0].charAt(0) + p[p.length - 1];
        return nombre.toLowerCase().replaceAll("\\s+", "");
    }

    private JPanel formPanel(String[] labels, JComponent[] fields) {
        JPanel p = new JPanel(new GridLayout(labels.length, 1, 0, 8));
        p.setBackground(UITheme.COLOR_BG);
        p.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        p.setPreferredSize(new Dimension(360, labels.length * 60));
        for (int i = 0; i < labels.length; i++) {
            JPanel row = new JPanel(new BorderLayout(0, 2));
            row.setOpaque(false);
            JLabel lbl = new JLabel(labels[i]);
            lbl.setFont(UITheme.FONT_BODY);
            fields[i].setPreferredSize(new Dimension(300, 32));
            row.add(lbl, BorderLayout.NORTH);
            row.add(fields[i], BorderLayout.CENTER);
            p.add(row);
        }
        return p;
    }

    private JTable styledTable(DefaultTableModel model) {
        JTable t = new JTable(model);
        t.setFont(UITheme.FONT_BODY);
        t.setRowHeight(30);
        t.setShowGrid(false);
        t.setIntercellSpacing(new Dimension(0, 1));
        t.setBackground(Color.WHITE);
        t.setSelectionBackground(new Color(220, 235, 255));
        t.setSelectionForeground(UITheme.COLOR_TEXT);
        t.getTableHeader().setFont(UITheme.FONT_SUBTITLE);
        t.getTableHeader().setBackground(UITheme.COLOR_PRIMARY);
        t.getTableHeader().setForeground(Color.WHITE);
        t.getTableHeader().setBorder(BorderFactory.createEmptyBorder());
        return t;
    }

    private class ObsTableRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int col) {
            Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, col);
            if (!isSelected) {
                String gravedad = (String) table.getModel().getValueAt(row, 3);
                Color bg = Color.WHITE;
                if ("Leve".equals(gravedad)) bg = new Color(255, 252, 220);
                else if ("Grave".equals(gravedad)) bg = new Color(255, 237, 210);
                else if ("Grav\u00edsima".equals(gravedad)) bg = new Color(255, 220, 220);
                c.setBackground(bg);
            }
            ((JLabel) c).setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
            return c;
        }
    }
}
