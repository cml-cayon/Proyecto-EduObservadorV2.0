package vista;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;

import modelo.observacion.Observacion;
import modelo.usuario.Estudiante;
import servicio.AuthService;
import servicio.ObservacionService;

public class EstudianteFrame extends JFrame {

    private Estudiante est;
    private ObservacionService service;
    private AuthService auth;
    private DefaultTableModel tableModel;

    public EstudianteFrame(Estudiante est, ObservacionService service, AuthService auth) {
        this.est = est;
        this.service = service;
        this.auth = auth;

        setTitle("EduObservador \u2013 Estudiante");
        setSize(820, 580);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setMinimumSize(new Dimension(680, 450));

        buildUI();
    }

    private void buildUI() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(UITheme.COLOR_BG);

        JPanel nav = UITheme.navBar("Estudiante: " + est.getNombre(), "Grado: " + est.getGrado());
        JPanel navRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 14));
        navRight.setOpaque(false);

        JButton btnPerfil = UITheme.iconButton("\u2699");
        btnPerfil.setToolTipText("Perfil y configuraci\u00f3n");
        JButton btnLogout = UITheme.iconButton("Salir");
        btnLogout.setToolTipText("Cerrar sesi\u00f3n");

        btnPerfil.addActionListener(e -> new PerfilDialog(this, est, () -> auth.save()).setVisible(true));
        btnLogout.addActionListener(e -> logout());

        navRight.add(btnPerfil);
        navRight.add(btnLogout);
        nav.add(navRight, BorderLayout.EAST);

        JPanel content = new JPanel(new BorderLayout(12, 12));
        content.setBackground(UITheme.COLOR_BG);
        content.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        JPanel summaryCard = UITheme.card();
        summaryCard.setLayout(new BoxLayout(summaryCard, BoxLayout.Y_AXIS));
        summaryCard.setPreferredSize(new Dimension(240, 0));

        JLabel nameLabel = new JLabel(est.getNombre(), SwingConstants.CENTER);
        nameLabel.setFont(UITheme.FONT_SUBTITLE);
        nameLabel.setForeground(UITheme.COLOR_PRIMARY);
        nameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel gradoLabel = new JLabel("Grado: " + est.getGrado(), SwingConstants.CENTER);
        gradoLabel.setFont(UITheme.FONT_BODY);
        gradoLabel.setForeground(UITheme.COLOR_TEXT_MUTED);
        gradoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JSeparator sep = new JSeparator();
        sep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        sep.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel infoTitle = UITheme.sectionLabel("Mis datos");
        infoTitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel lblCorreo = new JLabel("Correo: " + est.getCorreo());
        lblCorreo.setFont(UITheme.FONT_SMALL);
        lblCorreo.setForeground(UITheme.COLOR_TEXT_MUTED);
        lblCorreo.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel lblNac = new JLabel("Nacimiento: " + est.getFechaNacimiento());
        lblNac.setFont(UITheme.FONT_SMALL);
        lblNac.setForeground(UITheme.COLOR_TEXT_MUTED);
        lblNac.setAlignmentX(Component.LEFT_ALIGNMENT);

        summaryCard.add(Box.createVerticalStrut(10));
        summaryCard.add(nameLabel);
        summaryCard.add(Box.createVerticalStrut(4));
        summaryCard.add(gradoLabel);
        summaryCard.add(Box.createVerticalStrut(14));
        summaryCard.add(sep);
        summaryCard.add(Box.createVerticalStrut(14));
        summaryCard.add(infoTitle);
        summaryCard.add(Box.createVerticalStrut(6));
        summaryCard.add(lblCorreo);
        summaryCard.add(Box.createVerticalStrut(4));
        summaryCard.add(lblNac);
        summaryCard.add(Box.createVerticalGlue());

        JPanel rightPanel = new JPanel(new BorderLayout(0, 10));
        rightPanel.setOpaque(false);

        JPanel obsHeader = new JPanel(new BorderLayout());
        obsHeader.setOpaque(false);
        JLabel obsTitle = UITheme.sectionLabel("Mis Observaciones");
        JButton btnRefresh = UITheme.accentButton("\u21ba Actualizar");
        obsHeader.add(obsTitle, BorderLayout.WEST);
        obsHeader.add(btnRefresh, BorderLayout.EAST);

        String[] cols = {"Fecha", "Grado", "Gravedad", "Materia", "Descripci\u00f3n"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        JTable table = new JTable(tableModel);
        table.setFont(UITheme.FONT_BODY);
        table.setRowHeight(30);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 1));
        table.setBackground(Color.WHITE);
        table.setSelectionBackground(new Color(220, 235, 255));
        table.getTableHeader().setFont(UITheme.FONT_SUBTITLE);
        table.getTableHeader().setBackground(UITheme.COLOR_PRIMARY);
        table.getTableHeader().setForeground(Color.WHITE);
        table.setDefaultRenderer(Object.class, new GravedadRenderer());
        UITheme.enableTooltipAndDetail(table, new String[]{"Fecha", "Grado", "Gravedad", "Materia", "Descripci\u00f3n"});

        refreshTable();

        btnRefresh.addActionListener(e -> refreshTable());

        JPanel tableWrapper = new JPanel(new BorderLayout());
        tableWrapper.setBackground(Color.WHITE);
        tableWrapper.add(new JScrollPane(table), BorderLayout.CENTER);

        rightPanel.add(obsHeader, BorderLayout.NORTH);
        rightPanel.add(tableWrapper, BorderLayout.CENTER);

        content.add(summaryCard, BorderLayout.WEST);
        content.add(rightPanel, BorderLayout.CENTER);

        root.add(nav, BorderLayout.NORTH);
        root.add(content, BorderLayout.CENTER);
        setContentPane(root);
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        for (Observacion o : service.listar()) {
            if (o.getEstudiante().equalsIgnoreCase(est.getNombre())) {
                tableModel.addRow(new Object[]{
                    o.getFecha(), o.getGrado(),
                    UITheme.gravedadLabel(o.getGravedad()), o.getMateria(), o.getDescripcion()
                });
            }
        }
    }

    private void logout() {
        Object[] opciones = {"S\u00ed", "No"};
        int r = JOptionPane.showOptionDialog(this, "\u00bfCerrar sesi\u00f3n?", "Confirmar",
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);
        if (r == 0) {
            new controlador.LoginController().show();
            dispose();
        }
    }

    private class GravedadRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int col) {
            Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, col);
            if (!isSelected) {
                String grav = (String) table.getModel().getValueAt(row, 2);
                Color bg = Color.WHITE;
                if ("Leve".equals(grav)) bg = new Color(255, 252, 220);
                else if ("Grave".equals(grav)) bg = new Color(255, 237, 210);
                else if ("Grav\u00edsima".equals(grav)) bg = new Color(255, 220, 220);
                c.setBackground(bg);
            }
            ((JLabel) c).setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
            return c;
        }
    }
}
