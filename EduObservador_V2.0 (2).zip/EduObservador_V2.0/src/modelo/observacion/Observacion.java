package modelo.observacion;

import java.io.Serializable;

public class Observacion implements Serializable {
    private static final long serialVersionUID = 1L;

    private String estudiante;
    private String grado;
    private String gravedad;
    private String materia;
    private String fecha;
    private String descripcion;

    public Observacion(String estudiante, String grado, String gravedad, String materia, String fecha, String descripcion) {
        this.estudiante = estudiante;
        this.grado = grado;
        this.gravedad = gravedad;
        this.materia = materia;
        this.fecha = fecha;
        this.descripcion = descripcion;
    }

    public String getEstudiante() { return estudiante; }
    public String getGrado() { return grado; }
    public String getGravedad() { return gravedad; }
    public String getMateria() { return materia; }
    public String getFecha() { return fecha; }
    public String getDescripcion() { return descripcion; }

    public String getGravedadLabel() {
        switch (gravedad) {
            case "1": return "Leve";
            case "2": return "Grave";
            case "3": return "Gravísima";
            default: return gravedad;
        }
    }

    @Override
    public String toString() {
        return fecha + " | " + estudiante + " | " + grado + " | " + getGravedadLabel() + " | " + materia + " | " + descripcion;
    }
}
