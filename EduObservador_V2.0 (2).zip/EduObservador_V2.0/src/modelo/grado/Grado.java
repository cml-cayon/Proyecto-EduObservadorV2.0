package modelo.grado;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Grado implements Serializable {
    private static final long serialVersionUID = 1L;
    private String nombre;
    private List<String> estudiantesNombres;

    public Grado(String nombre) {
        this.nombre = nombre;
        this.estudiantesNombres = new ArrayList<>();
    }

    public String getNombre() { return nombre; }
    public List<String> getEstudiantesNombres() { return estudiantesNombres; }

    public void addEstudiante(String nombre) {
        if (!estudiantesNombres.contains(nombre)) {
            estudiantesNombres.add(nombre);
        }
    }

    @Override
    public String toString() { return nombre; }
}
