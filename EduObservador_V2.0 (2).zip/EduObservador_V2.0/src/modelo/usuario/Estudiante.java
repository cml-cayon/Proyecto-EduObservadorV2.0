package modelo.usuario;

public class Estudiante extends Usuario {
    private static final long serialVersionUID = 1L;
    private String grado;

    public Estudiante(String nombre, String fecha, String correo, String grado, String username, String password) {
        super(nombre, fecha, correo, username, password);
        this.grado = grado;
    }

    public String getGrado() { return grado; }

    @Override
    public String getRol() { return "Estudiante"; }
}
