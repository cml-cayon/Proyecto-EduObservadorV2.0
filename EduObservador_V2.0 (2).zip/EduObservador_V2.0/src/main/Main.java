package main;

import javax.swing.SwingUtilities;
import controlador.LoginController;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LoginController().show());
    }
}
