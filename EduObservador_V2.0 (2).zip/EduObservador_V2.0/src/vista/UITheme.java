package vista;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

public class UITheme {

    public static final Color COLOR_PRIMARY       = new Color(23, 58, 110);
    public static final Color COLOR_PRIMARY_LIGHT = new Color(41, 98, 175);
    public static final Color COLOR_ACCENT        = new Color(255, 180, 0);
    public static final Color COLOR_BG            = new Color(245, 247, 252);
    public static final Color COLOR_SURFACE       = Color.WHITE;
    public static final Color COLOR_TEXT          = new Color(30, 40, 60);
    public static final Color COLOR_TEXT_MUTED    = new Color(100, 115, 140);
    public static final Color COLOR_DANGER        = new Color(200, 50, 50);
    public static final Color COLOR_SUCCESS       = new Color(34, 139, 87);

    public static final Color LEVE_COLOR      = new Color(255, 200, 60);
    public static final Color GRAVE_COLOR     = new Color(230, 120, 30);
    public static final Color GRAVISIMA_COLOR = new Color(200, 40, 40);

    public static final Font FONT_TITLE    = new Font("Segoe UI", Font.BOLD, 22);
    public static final Font FONT_SUBTITLE = new Font("Segoe UI", Font.BOLD, 14);
    public static final Font FONT_BODY     = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font FONT_SMALL    = new Font("Segoe UI", Font.PLAIN, 11);
    public static final Font FONT_BUTTON   = new Font("Segoe UI", Font.BOLD, 13);

    public static void applyGlobalDefaults() {
        UIManager.put("Panel.background", COLOR_BG);
        UIManager.put("Label.font", FONT_BODY);
        UIManager.put("TextField.font", FONT_BODY);
        UIManager.put("TextArea.font", FONT_BODY);
        UIManager.put("Button.font", FONT_BUTTON);
        UIManager.put("ComboBox.font", FONT_BODY);
        UIManager.put("Table.font", FONT_BODY);
        UIManager.put("TableHeader.font", FONT_SUBTITLE);
    }

    public static JButton primaryButton(String text) {
        JButton b = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (getModel().isPressed()) {
                    g2.setColor(COLOR_PRIMARY.darker());
                } else if (getModel().isRollover()) {
                    g2.setColor(COLOR_PRIMARY_LIGHT);
                } else {
                    g2.setColor(COLOR_PRIMARY);
                }
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.setColor(Color.WHITE);
                g2.setFont(getFont());
                FontMetrics fm = g2.getFontMetrics();
                int x = (getWidth() - fm.stringWidth(getText())) / 2;
                int y = (getHeight() + fm.getAscent() - fm.getDescent()) / 2;
                g2.drawString(getText(), x, y);
                g2.dispose();
            }
        };
        b.setPreferredSize(new Dimension(b.getPreferredSize().width + 20, 36));
        b.setFont(FONT_BUTTON);
        b.setForeground(Color.WHITE);
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    public static JButton accentButton(String text) {
        JButton b = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (getModel().isPressed()) {
                    g2.setColor(COLOR_ACCENT.darker());
                } else if (getModel().isRollover()) {
                    g2.setColor(COLOR_ACCENT.brighter());
                } else {
                    g2.setColor(COLOR_ACCENT);
                }
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.setColor(COLOR_PRIMARY);
                g2.setFont(getFont());
                FontMetrics fm = g2.getFontMetrics();
                int x = (getWidth() - fm.stringWidth(getText())) / 2;
                int y = (getHeight() + fm.getAscent() - fm.getDescent()) / 2;
                g2.drawString(getText(), x, y);
                g2.dispose();
            }
        };
        b.setPreferredSize(new Dimension(b.getPreferredSize().width + 20, 36));
        b.setFont(FONT_BUTTON);
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    public static JButton dangerButton(String text) {
        JButton b = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isPressed() ? COLOR_DANGER.darker() : COLOR_DANGER);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.setColor(Color.WHITE);
                g2.setFont(getFont());
                FontMetrics fm = g2.getFontMetrics();
                int x = (getWidth() - fm.stringWidth(getText())) / 2;
                int y = (getHeight() + fm.getAscent() - fm.getDescent()) / 2;
                g2.drawString(getText(), x, y);
                g2.dispose();
            }
        };
        b.setPreferredSize(new Dimension(b.getPreferredSize().width + 20, 36));
        b.setFont(FONT_BUTTON);
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    public static JButton iconButton(String text) {
        JButton b = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (getModel().isRollover()) {
                    g2.setColor(new Color(255, 255, 255, 40));
                    g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                }
                g2.setColor(Color.WHITE);
                g2.setFont(getFont());
                FontMetrics fm = g2.getFontMetrics();
                int x = (getWidth() - fm.stringWidth(getText())) / 2;
                int y = (getHeight() + fm.getAscent() - fm.getDescent()) / 2;
                g2.drawString(getText(), x, y);
                g2.dispose();
            }
        };
        b.setPreferredSize(new Dimension(60, 36));
        b.setFont(FONT_BUTTON);
        b.setForeground(Color.WHITE);
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    public static JTextField textField() {
        JTextField tf = new JTextField();
        tf.setFont(FONT_BODY);
        tf.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(190, 205, 230), 1, true),
            BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
        tf.setBackground(Color.WHITE);
        return tf;
    }

    public static JPasswordField passwordField() {
        JPasswordField pf = new JPasswordField();
        pf.setFont(FONT_BODY);
        pf.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(190, 205, 230), 1, true),
            BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
        pf.setBackground(Color.WHITE);
        return pf;
    }

    public static JComboBox<String> comboBox(String[] items) {
        JComboBox<String> cb = new JComboBox<>(items);
        cb.setFont(FONT_BODY);
        cb.setBackground(Color.WHITE);
        cb.setBorder(BorderFactory.createLineBorder(new Color(190, 205, 230), 1));
        return cb;
    }

    public static JPanel card() {
        JPanel p = new JPanel();
        p.setBackground(COLOR_SURFACE);
        p.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(210, 220, 240), 1, true),
            BorderFactory.createEmptyBorder(14, 18, 14, 18)
        ));
        return p;
    }

    public static JPanel navBar(String title, String subtitle) {
        JPanel bar = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, COLOR_PRIMARY, getWidth(), 0, COLOR_PRIMARY_LIGHT);
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        bar.setPreferredSize(new Dimension(800, 65));
        bar.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 12));

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        left.setOpaque(false);

        JPanel texts = new JPanel();
        texts.setLayout(new BoxLayout(texts, BoxLayout.Y_AXIS));
        texts.setOpaque(false);
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(FONT_TITLE);
        titleLabel.setForeground(Color.WHITE);
        JLabel subLabel = new JLabel(subtitle);
        subLabel.setFont(FONT_SMALL);
        subLabel.setForeground(new Color(200, 215, 240));
        texts.add(titleLabel);
        texts.add(subLabel);
        left.add(texts);

        bar.add(left, BorderLayout.CENTER);
        return bar;
    }

    public static JLabel sectionLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(FONT_SUBTITLE);
        l.setForeground(COLOR_PRIMARY);
        l.setBorder(BorderFactory.createEmptyBorder(0, 0, 4, 0));
        return l;
    }

    public static JLabel mutedLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(FONT_SMALL);
        l.setForeground(COLOR_TEXT_MUTED);
        return l;
    }

    public static JPanel formRow(String labelText, JComponent field) {
        JPanel row = new JPanel(new BorderLayout(10, 0));
        row.setOpaque(false);
        JLabel lbl = new JLabel(labelText);
        lbl.setFont(FONT_BODY);
        lbl.setForeground(COLOR_TEXT);
        lbl.setPreferredSize(new Dimension(130, 32));
        row.add(lbl, BorderLayout.WEST);
        row.add(field, BorderLayout.CENTER);
        return row;
    }

    public static Color gravedadColor(String gravedad) {
        switch (gravedad) {
            case "1": return LEVE_COLOR;
            case "2": return GRAVE_COLOR;
            case "3": return GRAVISIMA_COLOR;
            default: return Color.GRAY;
        }
    }

    public static String gravedadLabel(String g) {
        switch (g) {
            case "1": return "Leve";
            case "2": return "Grave";
            case "3": return "Grav\u00edsima";
            default: return g;
        }
    }

    /**
     * Habilita tooltip con contenido completo al pasar el mouse,
     * y un dialogo de detalle al hacer doble clic en cualquier fila.
     */
    public static void enableTooltipAndDetail(JTable table, String[] columnNames) {
        table.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            @Override
            public void mouseMoved(java.awt.event.MouseEvent e) {
                int row = table.rowAtPoint(e.getPoint());
                int col = table.columnAtPoint(e.getPoint());
                if (row >= 0 && col >= 0) {
                    Object val = table.getValueAt(row, col);
                    table.setToolTipText(val != null ? "<html><body style='width:320px'>" + val + "</body></html>" : null);
                } else {
                    table.setToolTipText(null);
                }
            }
        });

        table.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                if (e.getClickCount() < 2) return;
                int row = table.getSelectedRow();
                if (row < 0) return;

                StringBuilder sb = new StringBuilder("<html><body style='font-family:Segoe UI;font-size:12px;width:380px'>");
                for (int c = 0; c < table.getColumnCount(); c++) {
                    String colName = (columnNames != null && c < columnNames.length)
                            ? columnNames[c] : table.getColumnName(c);
                    Object val = table.getValueAt(row, c);
                    sb.append("<b>").append(colName).append(":</b> ")
                      .append(val != null ? val.toString() : "-")
                      .append("<br><br>");
                }
                sb.append("</body></html>");

                JLabel content = new JLabel(sb.toString());
                content.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
                JOptionPane.showMessageDialog(table, content,
                        "Detalle del registro", JOptionPane.PLAIN_MESSAGE);
            }
        });
    }
}
