package vista;

import javax.swing.*;
import java.awt.*;
import controlador.LoginController;

public class LoginFrame extends JFrame {

    public JTextField txtUser;
    public JPasswordField txtPass;

    public LoginFrame(LoginController c) {
        setTitle("EduObservador - Inicio de sesi\u00f3n");
        setSize(420, 520);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        UITheme.applyGlobalDefaults();

        JPanel main = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, UITheme.COLOR_PRIMARY, 0, getHeight(), UITheme.COLOR_PRIMARY_LIGHT);
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };

        JPanel header = new JPanel();
        header.setOpaque(false);
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.setBorder(BorderFactory.createEmptyBorder(40, 20, 30, 20));

        JLabel title = new JLabel("EduObservador", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 28));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subtitle = new JLabel("Sistema de Observaciones Escolares", SwingConstants.CENTER);
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subtitle.setForeground(new Color(200, 215, 240));
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        header.add(title);
        header.add(Box.createVerticalStrut(4));
        header.add(subtitle);

        JPanel card = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Color.WHITE);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createEmptyBorder(28, 32, 28, 32));

        JLabel loginLabel = new JLabel("Iniciar Sesi\u00f3n");
        loginLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        loginLabel.setForeground(UITheme.COLOR_PRIMARY);
        loginLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel userLabel = new JLabel("Usuario");
        userLabel.setFont(UITheme.FONT_BODY);
        userLabel.setForeground(UITheme.COLOR_TEXT);
        userLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        txtUser = UITheme.textField();
        txtUser.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        txtUser.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel passLabel = new JLabel("Contrase\u00f1a");
        passLabel.setFont(UITheme.FONT_BODY);
        passLabel.setForeground(UITheme.COLOR_TEXT);
        passLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        txtPass = UITheme.passwordField();
        txtPass.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        txtPass.setAlignmentX(Component.LEFT_ALIGNMENT);
        txtPass.addActionListener(e -> c.login());

        JButton btnLogin = UITheme.primaryButton("Ingresar al sistema");
        btnLogin.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        btnLogin.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnLogin.addActionListener(e -> c.login());

        JLabel footer = new JLabel("EduObservador v2.0  \u2022  Sistema Escolar", SwingConstants.CENTER);
        footer.setFont(UITheme.FONT_SMALL);
        footer.setForeground(UITheme.COLOR_TEXT_MUTED);
        footer.setAlignmentX(Component.CENTER_ALIGNMENT);

        card.add(loginLabel);
        card.add(Box.createVerticalStrut(20));
        card.add(userLabel);
        card.add(Box.createVerticalStrut(4));
        card.add(txtUser);
        card.add(Box.createVerticalStrut(14));
        card.add(passLabel);
        card.add(Box.createVerticalStrut(4));
        card.add(txtPass);
        card.add(Box.createVerticalStrut(22));
        card.add(btnLogin);
        card.add(Box.createVerticalStrut(16));
        card.add(footer);

        JPanel cardWrapper = new JPanel(new BorderLayout());
        cardWrapper.setOpaque(false);
        cardWrapper.setBorder(BorderFactory.createEmptyBorder(0, 24, 30, 24));
        cardWrapper.add(card);

        main.add(header, BorderLayout.NORTH);
        main.add(cardWrapper, BorderLayout.CENTER);
        setContentPane(main);
    }
}
