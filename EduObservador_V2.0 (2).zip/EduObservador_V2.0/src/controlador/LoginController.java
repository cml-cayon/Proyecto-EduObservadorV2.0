package controlador;

import javax.swing.JOptionPane;
import modelo.usuario.*;
import servicio.AuthService;
import servicio.ObservacionService;
import vista.*;

public class LoginController {

    private LoginFrame frame;
    private AuthService auth;
    private ObservacionService obs;

    public LoginController() {
        auth = new AuthService();
        obs = new ObservacionService();
        frame = new LoginFrame(this);
    }

    public void show() {
        frame.setVisible(true);
    }

    public void login() {
        Usuario u = auth.login(
                frame.txtUser.getText().trim(),
                new String(frame.txtPass.getPassword())
        );

        if (u == null) {
            JOptionPane.showMessageDialog(frame, "Usuario o contraseña incorrectos.", "Acceso denegado", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (u instanceof Administrador) {
            new DashboardFrame(u, auth, obs).setVisible(true);
        } else if (u instanceof Docente) {
            new DocenteFrame((Docente) u, obs, auth).setVisible(true);
        } else if (u instanceof Estudiante) {
            new EstudianteFrame((Estudiante) u, obs, auth).setVisible(true);
        }

        frame.dispose();
    }
}
