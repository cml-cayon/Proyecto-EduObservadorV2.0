package vista;

import javax.swing.*;
import java.awt.*;
import modelo.usuario.*;

public class PerfilDialog extends JDialog {

    public PerfilDialog(JFrame parent, Usuario u, Runnable onSave) {
        super(parent, "Mi Perfil", true);
        setSize(420, 380);
        setLocationRelativeTo(parent);
        setResizable(false);

        JPanel main = new JPanel(new BorderLayout());
        main.setBackground(UITheme.COLOR_BG);

        JPanel header = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, UITheme.COLOR_PRIMARY, getWidth(), 0, UITheme.COLOR_PRIMARY_LIGHT);
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        header.setPreferredSize(new Dimension(420, 80));
        header.setLayout(new FlowLayout(FlowLayout.LEFT, 16, 16));

        JPanel headerTexts = new JPanel();
        headerTexts.setOpaque(false);
        headerTexts.setLayout(new BoxLayout(headerTexts, BoxLayout.Y_AXIS));
        JLabel nameLabel = new JLabel(u.getNombre());
        nameLabel.setFont(UITheme.FONT_SUBTITLE);
        nameLabel.setForeground(Color.WHITE);
        JLabel rolLabel = new JLabel(u.getRol());
        rolLabel.setFont(UITheme.FONT_SMALL);
        rolLabel.setForeground(new Color(200, 215, 240));
        headerTexts.add(nameLabel);
        headerTexts.add(rolLabel);
        header.add(headerTexts);

        JPanel infoCard = UITheme.card();
        infoCard.setLayout(new GridLayout(0, 1, 0, 10));
        infoCard.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));

        infoCard.add(infoRow("Nombre:", u.getNombre()));
        infoCard.add(infoRow("Correo:", u.getCorreo()));
        infoCard.add(infoRow("Nacimiento:", u.getFechaNacimiento()));

        if (u instanceof Docente) {
            infoCard.add(infoRow("Materia:", ((Docente) u).getMateria()));
        } else if (u instanceof Estudiante) {
            infoCard.add(infoRow("Grado:", ((Estudiante) u).getGrado()));
        }

        JPanel center = new JPanel(new BorderLayout());
        center.setBackground(UITheme.COLOR_BG);
        center.setBorder(BorderFactory.createEmptyBorder(14, 14, 8, 14));
        center.add(infoCard, BorderLayout.CENTER);

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 12));
        bottom.setBackground(UITheme.COLOR_BG);

        JButton btnPass = UITheme.accentButton("Cambiar Contrase\u00f1a");
        JButton btnClose = UITheme.primaryButton("Cerrar");

        btnPass.addActionListener(e -> {
            JPasswordField npf = UITheme.passwordField();
            JPasswordField cpf = UITheme.passwordField();
            JPanel pnl = new JPanel(new GridLayout(4, 1, 0, 6));
            pnl.setBackground(UITheme.COLOR_BG);
            pnl.add(new JLabel("Nueva contrase\u00f1a:"));
            pnl.add(npf);
            pnl.add(new JLabel("Confirmar contrase\u00f1a:"));
            pnl.add(cpf);

            int r = JOptionPane.showConfirmDialog(this, pnl, "Cambiar Contrase\u00f1a",
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (r == JOptionPane.OK_OPTION) {
                String np = new String(npf.getPassword());
                String cp = new String(cpf.getPassword());
                if (np.isBlank()) {
                    JOptionPane.showMessageDialog(this, "La contrase\u00f1a no puede estar vac\u00eda.", "Error", JOptionPane.ERROR_MESSAGE);
                } else if (!np.equals(cp)) {
                    JOptionPane.showMessageDialog(this, "Las contrase\u00f1as no coinciden.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    u.setPassword(np);
                    onSave.run();
                    JOptionPane.showMessageDialog(this, "Contrase\u00f1a actualizada correctamente.", "\u00c9xito", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        btnClose.addActionListener(e -> dispose());

        bottom.add(btnPass);
        bottom.add(btnClose);

        main.add(header, BorderLayout.NORTH);
        main.add(center, BorderLayout.CENTER);
        main.add(bottom, BorderLayout.SOUTH);
        setContentPane(main);
    }

    private JPanel infoRow(String label, String value) {
        JPanel row = new JPanel(new BorderLayout(8, 0));
        row.setBackground(Color.WHITE);
        JLabel lbl = new JLabel(label);
        lbl.setFont(UITheme.FONT_BODY);
        lbl.setForeground(UITheme.COLOR_TEXT_MUTED);
        lbl.setPreferredSize(new Dimension(130, 24));
        JLabel val = new JLabel(value);
        val.setFont(new Font("Segoe UI", Font.BOLD, 13));
        val.setForeground(UITheme.COLOR_TEXT);
        row.add(lbl, BorderLayout.WEST);
        row.add(val, BorderLayout.CENTER);
        return row;
    }
}
