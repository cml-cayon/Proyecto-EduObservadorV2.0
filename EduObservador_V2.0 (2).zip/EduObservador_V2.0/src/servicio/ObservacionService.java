package servicio;

import java.util.List;
import modelo.observacion.Observacion;
import repositorio.DataRepository;

public class ObservacionService {
    private DataRepository<Observacion> repo = new DataRepository<>("data/observaciones.dat");
    private List<Observacion> observaciones;

    public ObservacionService() {
        observaciones = repo.load();
    }

    public void registrar(Observacion o) {
        observaciones.add(0, o);
        save();
    }

    public List<Observacion> listar() { return observaciones; }

    public void save() {
        repo.save(observaciones);
    }
}
