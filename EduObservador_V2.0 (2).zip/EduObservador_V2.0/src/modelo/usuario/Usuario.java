package modelo.usuario;

import java.io.Serializable;

public abstract class Usuario implements Serializable {
    private static final long serialVersionUID = 1L;

    protected String nombre;
    protected String fechaNacimiento;
    protected String correo;
    protected String username;
    protected String password;

    public Usuario(String nombre, String fechaNacimiento, String correo, String username, String password) {
        this.nombre = nombre;
        this.fechaNacimiento = fechaNacimiento;
        this.correo = correo;
        this.username = username;
        this.password = password;
    }

    public String getNombre() { return nombre; }
    public String getFechaNacimiento() { return fechaNacimiento; }
    public String getCorreo() { return correo; }
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public abstract String getRol();
}
