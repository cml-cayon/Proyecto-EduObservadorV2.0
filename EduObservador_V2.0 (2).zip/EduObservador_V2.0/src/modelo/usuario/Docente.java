package modelo.usuario;

public class Docente extends Usuario {
    private static final long serialVersionUID = 1L;
    private String materia;

    public Docente(String nombre, String fecha, String correo, String materia, String username, String password) {
        super(nombre, fecha, correo, username, password);
        this.materia = materia;
    }

    public String getMateria() { return materia; }

    @Override
    public String getRol() { return "Docente"; }
}
