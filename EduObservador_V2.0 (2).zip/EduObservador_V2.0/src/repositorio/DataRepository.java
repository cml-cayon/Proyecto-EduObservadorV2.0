package repositorio;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class DataRepository<T> {
    private String file;

    public DataRepository(String file) {
        this.file = file;
    }

    @SuppressWarnings("unchecked")
    public List<T> load() {
        File f = new File(file);
        if (!f.exists()) return new ArrayList<>();
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f))) {
            return (List<T>) ois.readObject();
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    public void save(List<T> data) {
        File f = new File(file);
        if (f.getParentFile() != null) f.getParentFile().mkdirs();
        File tmp = new File(file + ".tmp");
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(tmp))) {
            oos.writeObject(data);
        } catch (Exception e) {
            e.printStackTrace();
            tmp.delete();
            return;
        }
        if (f.exists()) f.delete();
        tmp.renameTo(f);
    }
}
